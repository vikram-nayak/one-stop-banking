<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM accounts WHERE user_id = '$user_id'";
$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    $account = $result->fetch_assoc();
    $account_number = $account['account_number'];
    $balance = $account['balance'];
} else {
    $account_number = "N/A";
    $balance = "0.00";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Account Management</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<div class="navbar">
    <a href="account.php">Account Management</a>
    <a href="transfer.php">Fund Transfers</a>
    <a href="bill_payment.php">Bill Payments</a>
    <a href="transactions.php">Transaction History</a>
    <a href="logout.php">Logout</a>
</div>
    <h2>Account Management</h2>
    <p>Account Number: <?= $account_number ?></p>
    <p>Balance: $<?= $balance ?></p>
</body>
</html>
