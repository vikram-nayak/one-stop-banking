<?php
session_start();
include 'db.php'; // Ensure this file contains your database connection

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get user ID from session
$user_id = $_SESSION['user_id'];

// Query to fetch account details
$query = "SELECT * FROM accounts WHERE user_id = '$user_id'";
$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    $account = $result->fetch_assoc();
    $account_number = $account['account_number'];
    $balance = $account['balance'];
} else {
    $account_number = "N/A";
    $balance = "0.00";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="CSS/styles.css">
</head>
<body class="dashboard-page">
<div class="navbar">
    <a href="account.php">Account Management</a>
    <a href="transfer.php">Fund Transfers</a>
    <a href="bill_payment.php">Bill Payments</a>
    <a href="transactions.php">Transaction History</a>
    <a href="logout.php">Logout</a>
</div>
    <div class="container">
        <h2>Dashboard</h2>
        <p><strong>Account Number:</strong> <?= $account_number ?></p>
        <p><strong>Balance:</strong> $<?= $balance ?></p>
    </div>
</body>
</html>
