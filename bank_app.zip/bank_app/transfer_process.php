<?php
include 'db.php';
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $sender_id = $_SESSION['user_id'];
    $receiver_account = $_POST['receiver_account'];
    $amount = $_POST['amount'];
    
    $conn->begin_transaction();
    try {
        $conn->query("UPDATE accounts SET balance = balance - $amount WHERE user_id = $sender_id");
        $conn->query("UPDATE accounts SET balance = balance + $amount WHERE account_number = '$receiver_account'");
        $conn->query("INSERT INTO transactions (sender_id, receiver_account, amount) VALUES ($sender_id, '$receiver_account', $amount)");
        $conn->commit();
        echo "Transfer successful. <a href='dashboard.php'>Back to Dashboard</a>";
    } catch (Exception $e) {
        $conn->rollback();
        echo "Error: " . $e->getMessage();
    }
}
?>
