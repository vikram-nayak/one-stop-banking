<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get the user's account number
$user_id = $_SESSION['user_id'];
$account_query = "SELECT account_number, balance FROM accounts WHERE user_id = '$user_id'";
$account_result = $conn->query($account_query);

if (!$account_result || $account_result->num_rows === 0) {
    die("Account not found.");
}

$user_account = $account_result->fetch_assoc();
$sender_account = $user_account['account_number'];
$sender_balance = $user_account['balance'];

$message = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $receiver_account = $conn->real_escape_string($_POST['receiver_account']);
    $amount = (float) $_POST['amount'];

    // Input validation
    if ($receiver_account === $sender_account) {
        $message = "You cannot transfer funds to your own account.";
    } elseif ($amount <= 0) {
        $message = "Amount must be greater than zero.";
    } elseif ($amount > $sender_balance) {
        $message = "Insufficient balance.";
    } else {
        // Check if receiver account exists
        $receiver_query = "SELECT account_number FROM accounts WHERE account_number = '$receiver_account'";
        $receiver_result = $conn->query($receiver_query);

        if ($receiver_result && $receiver_result->num_rows > 0) {
            // Perform the transfer
            $conn->autocommit(false);

            try {
                // Deduct from sender
                $deduct_query = "UPDATE accounts SET balance = balance - $amount WHERE account_number = '$sender_account'";
                $conn->query($deduct_query);

                // Add to receiver
                $add_query = "UPDATE accounts SET balance = balance + $amount WHERE account_number = '$receiver_account'";
                $conn->query($add_query);

                // Record transaction
                $transaction_query = "INSERT INTO transactions (sender_account, receiver_account, amount, description)
                                      VALUES ('$sender_account', '$receiver_account', $amount, 'Fund Transfer')";
                $conn->query($transaction_query);

                $conn->commit();
                $message = "Transfer successful!";
            } catch (Exception $e) {
                $conn->rollback();
                $message = "Error during transfer: " . $e->getMessage();
            }

            $conn->autocommit(true);

            // Refresh balance
            $account_result = $conn->query($account_query);
            $user_account = $account_result->fetch_assoc();
            $sender_balance = $user_account['balance'];
        } else {
            $message = "Receiver account not found.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Fund Transfer</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body class="transfer-page">
    <div class="navbar">
        <a href="dashboard.php">Dashboard</a>
        <a href="transactions.php">Transaction History</a>
        <a href="bill_payment.php">Bill Payments</a>
        <a href="logout.php">Logout</a>
    </div>
    <div class="container">
        <h2>Transfer Funds</h2>
        <p><strong>Your Account:</strong> <?= $sender_account ?></p>
        <p><strong>Current Balance:</strong> $<?= number_format($sender_balance, 2) ?></p>

        <?php if ($message): ?>
            <p class="message"><?= $message ?></p>
        <?php endif; ?>

        <form method="post">
            <label for="receiver_account">Receiver's Account Number:</label>
            <input type="text" id="receiver_account" name="receiver_account" required>

            <label for="amount">Amount to Transfer:</label>
            <input type="number" id="amount" name="amount" step="0.01" required>

            <button type="submit">Transfer</button>
        </form>
    </div>
</body>
</html>
