<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get the user ID from the session
$user_id = $_SESSION['user_id'];

// Query to fetch transactions linked to the user's account
$query = "SELECT t.* FROM transactions t
          JOIN accounts a ON t.sender_account = a.account_number
          WHERE a.user_id = '$user_id'
          ORDER BY t.date DESC";

$result = $conn->query($query);

if (!$result) {
    die("Error: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Transaction History</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="navbar">
        <a href="account.php">Account Management</a>
        <a href="transfer.php">Fund Transfers</a>
        <a href="bill_payment.php">Bill Payments</a>
        <a href="logout.php">Logout</a>
    </div>
    <div class="container">
        <h2>Transaction History</h2>
        <ul>
            <?php while ($row = $result->fetch_assoc()): ?>
                <li>
                    <strong>Date:</strong> <?= $row['date'] ?><br>
                    <strong>Amount:</strong> $<?= $row['amount'] ?><br>
                    <strong>To:</strong> <?= $row['receiver_account'] ?><br>
                    <strong>Description:</strong> <?= $row['description'] ?? 'N/A' ?>
                </li>
            <?php endwhile; ?>
        </ul>
        <?php if ($result->num_rows === 0): ?>
            <p>No transactions found.</p>
        <?php endif; ?>
    </div>
</body>
</html>
