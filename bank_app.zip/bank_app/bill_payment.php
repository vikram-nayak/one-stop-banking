<?php
session_start();
include 'db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get user account details
$user_id = $_SESSION['user_id'];
$account_query = "SELECT account_number, balance FROM accounts WHERE user_id = '$user_id'";
$account_result = $conn->query($account_query);

if (!$account_result || $account_result->num_rows === 0) {
    die("Account not found.");
}

$user_account = $account_result->fetch_assoc();
$sender_account = $user_account['account_number'];
$sender_balance = $user_account['balance'];

$message = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bill_type = $conn->real_escape_string($_POST['bill_type']);
    $amount = (float) $_POST['amount'];

    // Input validation
    if ($amount <= 0) {
        $message = "Amount must be greater than zero.";
    } elseif ($amount > $sender_balance) {
        $message = "Insufficient balance.";
    } else {
        // Process bill payment
        $conn->autocommit(false);

        try {
            // Deduct from sender's balance
            $deduct_query = "UPDATE accounts SET balance = balance - $amount WHERE account_number = '$sender_account'";
            $conn->query($deduct_query);

            // Record the transaction as a bill payment
            $transaction_query = "INSERT INTO transactions (sender_account, receiver_account, amount, description)
                                  VALUES ('$sender_account', 'UtilityCompany', $amount, '$bill_type Bill Payment')";
            $conn->query($transaction_query);

            $conn->commit();
            $message = "Bill payment successful!";
        } catch (Exception $e) {
            $conn->rollback();
            $message = "Error during bill payment: " . $e->getMessage();
        }

        $conn->autocommit(true);

        // Refresh account balance
        $account_result = $conn->query($account_query);
        $user_account = $account_result->fetch_assoc();
        $sender_balance = $user_account['balance'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bill Payment</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body class="bill-payment-page">
    <div class="navbar">
        <a href="dashboard.php">Dashboard</a>
        <a href="transactions.php">Transaction History</a>
        <a href="transfer.php">Transfer Funds</a>
        <a href="logout.php">Logout</a>
    </div>
    <div class="container">
        <h2>Pay Bill</h2>
        <p><strong>Your Account:</strong> <?= $sender_account ?></p>
        <p><strong>Current Balance:</strong> $<?= number_format($sender_balance, 2) ?></p>

        <?php if ($message): ?>
            <p class="message"><?= $message ?></p>
        <?php endif; ?>

        <form method="post">
            <label for="bill_type">Bill Type:</label>
            <select id="bill_type" name="bill_type" required>
                <option value="Electricity">Electricity</option>
                <option value="Water">Water</option>
                <option value="Internet">Internet</option>
                <option value="Gas">Gas</option>
                <option value="Mobile">Mobile</option>
            </select>

            <label for="amount">Amount to Pay:</label>
            <input type="number" id="amount" name="amount" step="0.01" required>

            <button type="submit">Pay Bill</button>
        </form>
    </div>
</body>
</html>
